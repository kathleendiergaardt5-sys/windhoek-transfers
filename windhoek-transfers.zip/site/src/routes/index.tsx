import { createFileRoute } from "@tanstack/react-router";
import { createServerFn } from "@tanstack/react-start";
import { readFile } from "node:fs/promises";

import BookingForm from "~/components/BookingForm";

// Read the (optional) business name at request time so the page can be
// personalized by writing site.json — no rebuild needed. Resolves relative to the
// server's working directory (the site root). Falls back to "" if absent/invalid.
const getBusinessName = createServerFn({ method: "GET" }).handler(async () => {
  try {
    const cfg = JSON.parse(await readFile("site.json", "utf8")) as {
      businessName?: string;
    };
    return cfg.businessName?.trim() ?? "";
  } catch {
    return "";
  }
});

export const Route = createFileRoute("/")({
  loader: () => getBusinessName(),
  component: Home,
});

const FALLBACK_NAME = "Assured Transfers & Airport Shuttle";

function Home() {
  const businessName = Route.useLoaderData() || FALLBACK_NAME;
  return (
    <div className="flex min-h-dvh flex-col bg-gradient-to-b from-slate-50 via-white to-slate-100 dark:from-slate-950 dark:via-slate-900 dark:to-slate-950">
      {/* Header */}
      <header className="mx-auto w-full max-w-2xl px-4 pb-6 pt-10 text-center sm:pt-14">
        <span className="inline-flex h-14 w-14 items-center justify-center rounded-2xl bg-gradient-to-br from-teal-500 to-blue-600 text-white shadow-lg shadow-teal-500/20">
          <svg
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth="1.8"
            strokeLinecap="round"
            strokeLinejoin="round"
            className="h-7 w-7"
            aria-hidden="true"
          >
            <path d="M3.5 17.5V8.75A2.25 2.25 0 0 1 5.75 6.5h8.5l3 3.25 3.25.75v6.5" />
            <path d="M14.25 6.5v4H20.5" />
            <circle cx="8" cy="17.75" r="1.75" />
            <circle cx="16.5" cy="17.75" r="1.75" />
          </svg>
        </span>
        <h1 className="mt-4 text-2xl font-bold tracking-tight text-slate-900 sm:text-3xl dark:text-white">
          {businessName}
        </h1>
        <p className="mx-auto mt-2 max-w-md text-base text-slate-600 dark:text-slate-400">
          Airport shuttles &amp; reliable transfers to hotels, lodges and
          guesthouses. Request your ride in under a minute — we confirm on WhatsApp.
        </p>
        <ul className="mt-4 flex flex-wrap items-center justify-center gap-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300">
          {["✈️ Airport shuttles", "🏨 Hotels", "🌳 Lodges", "🏡 Guesthouses"].map((t) => (
            <li
              key={t}
              className="rounded-full border border-slate-200 bg-white px-3 py-1 shadow-sm dark:border-slate-800 dark:bg-slate-900"
            >
              {t}
            </li>
          ))}
        </ul>
      </header>

      {/* Booking form */}
      <main className="flex-1">
        <BookingForm />
      </main>

      {/* Footer */}
      <footer className="mx-auto w-full max-w-2xl px-4 pb-8 text-center text-xs text-slate-400 dark:text-slate-600">
        <p>
          {businessName} · Bookings via WhatsApp ·{" "}
          <a
            href="https://cto.new"
            className="underline transition hover:text-slate-500 dark:hover:text-slate-400"
          >
            cto.new
          </a>
        </p>
      </footer>
    </div>
  );
}
