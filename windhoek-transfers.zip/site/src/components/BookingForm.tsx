import { cloneElement, isValidElement, useState, type ReactElement, type ReactNode } from "react";

/**
 * Booking request form for Assured Transfers & Airport Shuttle.
 * Covers airport shuttles and transfers to/from hotels, lodges and guesthouses.
 * Validates on the client and hands off to WhatsApp via a wa.me deep link —
 * no backend, no payment flow.
 */
export const WHATSAPP_NUMBER = "264813463"; // country code + number, no "+"

type ServiceType = "lodge" | "guesthouse" | "hotel" | "airport";

/** The four booking types offered. Order matches the on-screen grid. */
const SERVICE_TYPES: { value: ServiceType; label: string; emoji: string }[] = [
  { value: "lodge", label: "Lodge", emoji: "🌳" },
  { value: "guesthouse", label: "Guesthouse", emoji: "🏡" },
  { value: "hotel", label: "Hotel", emoji: "🏨" },
  { value: "airport", label: "Airport shuttle", emoji: "✈️" },
];

function serviceTypeMeta(value: string): { label: string; emoji: string } {
  return SERVICE_TYPES.find((s) => s.value === value) ?? { label: value, emoji: "🚖" };
}

type FieldName =
  | "serviceType"
  | "name"
  | "phone"
  | "pickup"
  | "dropoff"
  | "date"
  | "time"
  | "passengers";
type FormValues = Record<FieldName, string>;
type FormErrors = Partial<Record<FieldName, string>>;

const EMPTY: FormValues = {
  serviceType: "",
  name: "",
  phone: "",
  pickup: "",
  dropoff: "",
  date: "",
  time: "",
  passengers: "",
};

/** Today's date as YYYY-MM-DD in the visitor's local timezone. */
function todayISO(): string {
  const d = new Date();
  const local = new Date(d.getTime() - d.getTimezoneOffset() * 60_000);
  return local.toISOString().split("T")[0];
}

/** "2026-08-10" -> "Mon 10 Aug 2026"; falls back to the raw value. */
function formatDate(iso: string): string {
  const d = new Date(`${iso}T00:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-GB", {
    weekday: "short",
    day: "numeric",
    month: "short",
    year: "numeric",
  });
}

/** "14:30" -> "2:30 PM"; falls back to the raw value. */
function formatTime(time: string): string {
  const m = /^(\d{2}):(\d{2})$/.exec(time);
  if (!m) return time;
  const d = new Date(2000, 0, 1, Number(m[1]), Number(m[2]));
  if (Number.isNaN(d.getTime())) return time;
  return d.toLocaleTimeString("en-US", { hour: "numeric", minute: "2-digit" });
}

function validate(v: FormValues): FormErrors {
  const e: FormErrors = {};

  if (!v.serviceType) e.serviceType = "Please choose a transfer type.";

  if (!v.name.trim()) e.name = "Please enter your full name.";
  else if (v.name.trim().length < 2) e.name = "Your name looks too short.";

  const digits = v.phone.replace(/\D/g, "");
  if (!v.phone.trim()) e.phone = "Please enter your phone number.";
  else if (digits.length < 7 || digits.length > 15)
    e.phone = "Enter a valid phone number, e.g. +264 81 123 4567.";

  if (!v.pickup.trim()) e.pickup = "Please enter your pickup location.";
  if (!v.dropoff.trim()) e.dropoff = "Please enter your drop-off location.";

  if (!v.date) e.date = "Please choose your travel date.";
  else if (v.date < todayISO()) e.date = "The travel date can't be in the past.";

  if (!v.time) e.time = "Please choose a pickup time.";

  const p = Number(v.passengers);
  if (!v.passengers.trim()) e.passengers = "Please enter the number of passengers.";
  else if (!Number.isInteger(p) || p < 1)
    e.passengers = "Enter at least 1 passenger.";
  else if (p > 30)
    e.passengers = "Maximum 30 passengers — for larger groups please contact us directly.";

  return e;
}

/** The nicely formatted WhatsApp message containing every field. */
function buildMessage(v: FormValues): string {
  const type = serviceTypeMeta(v.serviceType);
  return [
    "🚖 *New Booking Request* — Assured Transfers & Airport Shuttle",
    "",
    `${type.emoji} *Service Type:* ${type.label}`,
    `👤 *Full Name:* ${v.name.trim()}`,
    `📞 *Phone Number:* ${v.phone.trim()}`,
    `📍 *Pickup Location:* ${v.pickup.trim()}`,
    `🏁 *Drop-off Location:* ${v.dropoff.trim()}`,
    `📅 *Date:* ${formatDate(v.date)}`,
    `🕐 *Time:* ${formatTime(v.time)}`,
    `👥 *Number of Passengers:* ${v.passengers.trim()}`,
    "",
    "Please confirm this transfer. Thank you!",
  ].join("\n");
}

function waLink(message: string): string {
  return `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(message)}`;
}

const inputBase =
  "w-full rounded-xl border bg-white px-3.5 py-3 text-base text-slate-900 shadow-sm " +
  "placeholder:text-slate-400 focus:outline-none focus:ring-2 transition " +
  "dark:bg-slate-800 dark:text-slate-100 dark:placeholder:text-slate-500 " +
  "aria-[invalid=true]:border-red-500 aria-[invalid=true]:focus:ring-red-400 " +
  "border-slate-300 focus:border-teal-500 focus:ring-teal-500/30 " +
  "dark:border-slate-600 dark:focus:border-teal-400 dark:focus:ring-teal-400/30";

function Field({
  id,
  label,
  error,
  className = "",
  children,
}: {
  id: string;
  label: string;
  error?: string;
  className?: string;
  children: ReactNode;
}) {
  // Inject `id` into the single child control so <label htmlFor> is actually
  // associated with the input (accessibility + focus targeting).
  const control =
    isValidElement(children)
      ? cloneElement(children as ReactElement<{ id?: string }>, { id })
      : children;
  return (
    <div className={className}>
      <label
        htmlFor={id}
        className="mb-1.5 block text-sm font-semibold text-slate-700 dark:text-slate-300"
      >
        {label}
      </label>
      {control}
      {error ? (
        <p id={`${id}-error`} className="mt-1.5 text-sm font-medium text-red-600 dark:text-red-400">
          {error}
        </p>
      ) : null}
    </div>
  );
}

/** Shared aria wiring for an input that may carry an error. */
function inputAria(id: string, error?: string) {
  return {
    "aria-invalid": error ? true : undefined,
    "aria-describedby": error ? `${id}-error` : undefined,
  };
}

export default function BookingForm() {
  const [values, setValues] = useState<FormValues>(EMPTY);
  const [errors, setErrors] = useState<FormErrors>({});
  const [attempted, setAttempted] = useState(false);
  const [sent, setSent] = useState(false);
  const [lastMessage, setLastMessage] = useState("");
  const [copied, setCopied] = useState(false);

  const set =
    (field: FieldName) =>
    (ev: React.ChangeEvent<HTMLInputElement>) => {
      setValues((v) => ({ ...v, [field]: ev.target.value }));
      // Clear the field's error as the visitor fixes it.
      if (errors[field]) setErrors((e) => ({ ...e, [field]: undefined }));
    };

  function handleSubmit(ev: React.FormEvent<HTMLFormElement>) {
    ev.preventDefault();
    const errs = validate(values);
    setErrors(errs);
    setAttempted(true);

    const firstInvalid = (Object.keys(errs) as FieldName[]).find((k) => errs[k]);
    if (firstInvalid) {
      setSent(false);
      if (firstInvalid === "serviceType") {
        document.querySelector<HTMLInputElement>('input[name="serviceType"]')?.focus();
      } else {
        document.getElementById(firstInvalid)?.focus();
      }
      return;
    }

    const message = buildMessage(values);
    setLastMessage(message);
    setSent(true);
    window.open(waLink(message), "_blank", "noopener");
  }

  function handleReset() {
    setValues(EMPTY);
    setErrors({});
    setAttempted(false);
    setSent(false);
    setLastMessage("");
    setCopied(false);
  }

  async function handleCopy() {
    const text = lastMessage;
    try {
      await navigator.clipboard.writeText(text);
    } catch {
      // Older browsers / non-secure contexts: fall back to a hidden textarea.
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.position = "fixed";
      ta.style.opacity = "0";
      document.body.appendChild(ta);
      ta.select();
      document.execCommand("copy");
      document.body.removeChild(ta);
    }
    setCopied(true);
    window.setTimeout(() => setCopied(false), 2000);
  }

  const errorList = Object.values(errors).filter(Boolean) as string[];
  const showSummary = attempted && errorList.length > 0;

  return (
    <div className="mx-auto w-full max-w-2xl px-4 pb-12 sm:px-6">
      <div className="overflow-hidden rounded-2xl bg-white shadow-xl ring-1 ring-slate-200 dark:bg-slate-900 dark:ring-slate-800">
        {/* Card header */}
        <div className="bg-gradient-to-r from-teal-600 to-blue-700 px-6 py-5 sm:px-8">
          <h2 className="text-xl font-bold text-white sm:text-2xl">Request a booking</h2>
          <p className="mt-1 text-sm text-teal-50/95">
            Airport shuttles &amp; transfers to hotels, lodges and guesthouses —{" "}
            we&rsquo;ll confirm your ride on WhatsApp.
          </p>
        </div>

        {sent ? (
          /* Success state — WhatsApp should already be open with the message. */
          <div role="status" className="px-6 py-8 sm:px-8">
            <div className="flex items-start gap-3.5">
              <svg
                viewBox="0 0 24 24"
                fill="currentColor"
                className="h-8 w-8 shrink-0 text-emerald-500"
                aria-hidden="true"
              >
                <path
                  fillRule="evenodd"
                  d="M12 2.25c-5.385 0-9.75 4.365-9.75 9.75s4.365 9.75 9.75 9.75 9.75-4.365 9.75-9.75S17.385 2.25 12 2.25Zm4.28 7.28a.75.75 0 0 0-1.06-1.06l-4.47 4.47-1.97-1.97a.75.75 0 0 0-1.06 1.06l2.5 2.5a.75.75 0 0 0 1.06 0l5-5Z"
                  clipRule="evenodd"
                />
              </svg>
              <div className="min-w-0">
                <p className="text-lg font-bold text-slate-900 dark:text-white">
                  Your request is ready to send!
                </p>
                <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-400">
                  WhatsApp should have opened with your booking request. Just press{" "}
                  <strong className="font-semibold text-slate-800 dark:text-slate-200">Send</strong>{" "}
                  there to complete it. If it didn&rsquo;t open, use the buttons below.
                </p>
                <div className="mt-4 flex flex-wrap gap-2.5">
                  <a
                    href={waLink(lastMessage)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 rounded-xl bg-[#25D366] px-4 py-2.5 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1ebe5b] focus:outline-none focus:ring-2 focus:ring-[#25D366]/50 focus:ring-offset-2"
                  >
                    Open WhatsApp
                  </a>
                  <button
                    type="button"
                    onClick={handleCopy}
                    className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 shadow-sm transition hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-teal-500/40 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                  >
                    {copied ? "Copied ✓" : "Copy message"}
                  </button>
                  <button
                    type="button"
                    onClick={handleReset}
                    className="inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-semibold text-slate-500 transition hover:text-slate-700 focus:outline-none focus:ring-2 focus:ring-teal-500/40 dark:text-slate-400 dark:hover:text-slate-200"
                  >
                    Start a new request
                  </button>
                </div>
              </div>
            </div>
            {/* Visible copy of exactly what was sent, so nothing is lost. */}
            <pre className="mt-5 whitespace-pre-wrap rounded-xl bg-slate-50 px-4 py-3 text-sm leading-relaxed text-slate-700 ring-1 ring-slate-200 dark:bg-slate-800/60 dark:text-slate-300 dark:ring-slate-700">
              {lastMessage}
            </pre>
          </div>
        ) : (
          <form onSubmit={handleSubmit} noValidate className="px-6 py-6 sm:px-8 sm:py-8">
            {showSummary && (
              <div
                role="alert"
                className="mb-5 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700 dark:border-red-900 dark:bg-red-950/40 dark:text-red-300"
              >
                <p className="font-bold">Please fix the following before sending:</p>
                <ul className="mt-1.5 list-inside list-disc space-y-0.5">
                  {errorList.map((msg) => (
                    <li key={msg}>{msg}</li>
                  ))}
                </ul>
              </div>
            )}

            {/* Service / property type — radio group, required, keyboard-accessible. */}
            <fieldset
              className="mb-5"
              aria-invalid={errors.serviceType ? true : undefined}
              aria-describedby={errors.serviceType ? "serviceType-error" : undefined}
            >
              <legend className="mb-1.5 block text-sm font-semibold text-slate-700 dark:text-slate-300">
                What are you booking?
              </legend>
              <p className="mb-3 text-xs leading-relaxed text-slate-500 dark:text-slate-400">
                A transfer to or from a lodge, guesthouse, hotel, or the airport.
              </p>
              <div className="grid grid-cols-2 gap-2.5 sm:gap-3">
                {SERVICE_TYPES.map((s) => (
                  <label
                    key={s.value}
                    className="flex cursor-pointer items-center gap-2.5 rounded-xl border border-slate-300 bg-white px-3 py-3 text-sm font-semibold text-slate-800 shadow-sm transition has-[:focus-visible]:ring-2 has-[:focus-visible]:ring-teal-500/50 has-[:checked]:border-teal-600 has-[:checked]:bg-teal-50 has-[:checked]:ring-2 has-[:checked]:ring-teal-500/30 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 dark:has-[:checked]:border-teal-400 dark:has-[:checked]:bg-teal-950/50"
                  >
                    <input
                      type="radio"
                      name="serviceType"
                      value={s.value}
                      checked={values.serviceType === s.value}
                      onChange={set("serviceType")}
                      className="sr-only"
                    />
                    <span className="text-lg leading-none" aria-hidden="true">
                      {s.emoji}
                    </span>
                    <span>{s.label}</span>
                  </label>
                ))}
              </div>
              {errors.serviceType ? (
                <p
                  id="serviceType-error"
                  className="mt-1.5 text-sm font-medium text-red-600 dark:text-red-400"
                >
                  {errors.serviceType}
                </p>
              ) : null}
            </fieldset>

            <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
              <Field id="name" label="Full name" error={errors.name}>
                <input
                  type="text"
                  autoComplete="name"
                  placeholder="e.g. Maria Nakale"
                  className={inputBase}
                  value={values.name}
                  onChange={set("name")}
                  {...inputAria("name", errors.name)}
                />
              </Field>

              <Field id="phone" label="Phone number" error={errors.phone}>
                <input
                  type="tel"
                  autoComplete="tel"
                  inputMode="tel"
                  placeholder="+264 81 123 4567"
                  className={inputBase}
                  value={values.phone}
                  onChange={set("phone")}
                  {...inputAria("phone", errors.phone)}
                />
              </Field>

              <Field id="pickup" label="Pickup location" error={errors.pickup} className="sm:col-span-2">
                <input
                  type="text"
                  autoComplete="street-address"
                  placeholder="e.g. your hotel, lodge, guesthouse, airport, or street address"
                  className={inputBase}
                  value={values.pickup}
                  onChange={set("pickup")}
                  {...inputAria("pickup", errors.pickup)}
                />
              </Field>

              <Field id="dropoff" label="Drop-off location" error={errors.dropoff} className="sm:col-span-2">
                <input
                  type="text"
                  autoComplete="street-address"
                  placeholder="Where would you like to be taken?"
                  className={inputBase}
                  value={values.dropoff}
                  onChange={set("dropoff")}
                  {...inputAria("dropoff", errors.dropoff)}
                />
              </Field>

              <Field id="date" label="Date" error={errors.date}>
                <input
                  type="date"
                  min={todayISO()}
                  className={inputBase}
                  value={values.date}
                  onChange={set("date")}
                  {...inputAria("date", errors.date)}
                />
              </Field>

              <Field id="time" label="Time" error={errors.time}>
                <input
                  type="time"
                  className={inputBase}
                  value={values.time}
                  onChange={set("time")}
                  {...inputAria("time", errors.time)}
                />
              </Field>

              <Field id="passengers" label="Number of passengers" error={errors.passengers} className="sm:col-span-2">
                <input
                  type="number"
                  inputMode="numeric"
                  min={1}
                  max={30}
                  placeholder="e.g. 2"
                  className={inputBase}
                  value={values.passengers}
                  onChange={set("passengers")}
                  {...inputAria("passengers", errors.passengers)}
                />
              </Field>
            </div>

            <button
              type="submit"
              className="mt-7 flex w-full items-center justify-center gap-2.5 rounded-xl bg-[#25D366] px-6 py-4 text-lg font-bold text-white shadow-lg shadow-emerald-500/25 transition hover:bg-[#1ebe5b] hover:shadow-emerald-500/30 focus:outline-none focus:ring-2 focus:ring-[#25D366]/50 focus:ring-offset-2 active:scale-[0.99]"
            >
              <svg viewBox="0 0 448 512" fill="currentColor" className="h-6 w-6" aria-hidden="true">
                <path d="M380.9 97.1C339 55.1 283.2 32 223.9 32c-122.4 0-222 99.6-222 222 0 39.1 10.2 77.3 29.6 111L0 480l117.7-30.9c32.4 17.7 68.9 27 106.1 27h.1c122.3 0 224.1-99.6 224.1-222 0-59.3-25.2-115-67.1-157zm-157 341.6c-33.2 0-65.7-8.9-94-25.7l-6.7-4-69.8 18.3L72 359.2l-4.4-7c-18.5-29.4-28.2-63.3-28.2-98.2 0-101.7 82.8-184.5 184.6-184.5 49.3 0 95.6 19.2 130.4 54.1 34.8 34.9 56.2 81.2 56.1 130.5 0 101.8-84.9 184.6-186.6 184.6zm101.2-138.2c-5.5-2.8-32.8-16.2-37.9-18-5.1-1.9-8.8-2.8-12.5 2.8-3.7 5.6-14.3 18-17.6 21.8-3.2 3.7-6.5 4.2-12 1.4-32.6-16.3-54-29.1-75.5-66-5.7-9.8 5.7-9.1 16.3-30.3 1.8-3.7.9-6.9-.5-9.7-1.4-2.8-12.5-30.1-17.1-41.2-4.5-10.8-9.1-9.3-12.5-9.5-3.2-.2-6.9-.2-10.6-.2-3.7 0-9.7 1.4-14.8 6.9-5.1 5.6-19.4 19-19.4 46.3 0 27.3 19.9 53.7 22.6 57.4 2.8 3.7 39.1 59.7 94.8 83.8 35.2 15.2 49 16.5 66.6 13.9 10.7-1.6 32.8-13.4 37.4-26.4 4.6-13 4.6-24.1 3.2-26.4-1.3-2.5-5-3.9-10.5-6.6z" />
              </svg>
              Submit via WhatsApp
            </button>
            <p className="mt-3 text-center text-xs text-slate-400 dark:text-slate-500">
              Submitting opens WhatsApp with your request — nothing is sent until you press Send.
            </p>
          </form>
        )}
      </div>
    </div>
  );
}
